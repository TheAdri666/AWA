const router = require('express').Router();
const UserCtrl = require('../controllers/userController');

//DELETE(?
router
  .route('/')
  .put(UserCtrl.deleteTodo);
//END

router
  .route('/:id')
  .get(UserCtrl.findUserByName)
  .delete(UserCtrl.deleteUser)
  //.put(UserCtrl.deleteTodo);
  
module.exports = router;